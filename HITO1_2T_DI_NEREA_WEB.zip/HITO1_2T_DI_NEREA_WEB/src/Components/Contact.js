import React from "react";

const Contact = () => {
  return (
    <div id="contacto" className="contact-page-wrapper">
      <h1 className="primary-heading">Tienes alguna pregunta?</h1>
      <h1 className="primary-heading">Dejanos ayudarte</h1>
      <h4>Si tienes cualquier duda sobre nuestros servicios, alimentos, </h4>
      <h4>productos, o si quieres saber cualquier cosa, no dudes en dejarnos tu email para ayudarte</h4>
      <div className="contact-form-container">
        <input type="text" placeholder="tumail@gmail.com" />
        <button className="secondary-button">Enviar</button>
      </div>
      <div className="contact-form-container">
        <input type="text" placeholder="Tu pregunta" />
        <button className="secondary-button">Enviar</button>
      </div>
    </div>
  );
};

export default Contact;
