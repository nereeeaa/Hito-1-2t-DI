import React from "react";
import ProfilePic from "../Assets/john-doe-image.png";
import { AiFillStar } from "react-icons/ai";

const Testimonial = () => {
  return (
    <div id="opiniones" className="work-section-wrapper">
      <div className="work-section-top">
        <p className="primary-subheading">Opiniones</p>
        <h1 className="primary-heading">Que opina la gente</h1>
        <p className="primary-text">
          Para nosotros es muy importante la opinión de la gente ya que queremos que todos os sintais satisfechos y repitais, 
          por eso valoramos mucho todas vuestras opiniones.
        </p>
      </div>
      <div className="testimonial-section-bottom">
        <img src={ProfilePic} alt="" />
        <p>
          Repetiré!  Me encanto la comida que pedí, en mi caso pedí una ensalada cesar especial y un poke de salmon, 
          se nota la calidad de los alimentos, además de la rapidez de entrega.
        </p>
        <div className="testimonials-stars-container">
          <AiFillStar />
          <AiFillStar />
          <AiFillStar />
          <AiFillStar />
          <AiFillStar />
        </div>
        <h2>Jorge López</h2>
      </div>
    </div>
  );
};

export default Testimonial;
