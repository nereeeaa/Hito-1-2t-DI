import React from "react";
import AboutBackground from "../Assets/about-background.png";
import AboutBackgroundImage from "../Assets/about-background-image.png";
import { BsFillPlayCircleFill } from "react-icons/bs";

const About = () => {
  return (
    <div id="about" className="about-section-container">
      <div className="about-background-image-container">
        <img src={AboutBackground} alt="" />
      </div>
      <div className="about-section-image-container">
        <img src={AboutBackgroundImage} alt="" />
      </div>
      <div className="about-section-text-container">
        <p className="primary-subheading">Sobre nosotros</p>
        <h1 className="primary-heading">
          La comida es una parte importante para una dieta balanceada
        </h1>
        <p className="primary-text">
          Nuestras opciones son sanas y saludables, pero sobre todo están riquísimas, y notarás la calidad de nuestros alimentos.
        </p>
        <p className="primary-text">
          En nuestro canal de YouTube tenemos varios videos, además en TikTok hacemos directo preparando los pedidos que nos haceis para que veaís como lo preparamos.
        </p>
        <div className="about-buttons-container">
          <button className="secondary-button">Saber más</button>
          <button className="watch-video-button">
            <BsFillPlayCircleFill /> Ver Video
          </button>
        </div>
      </div>
    </div>
  );
};

export default About;
