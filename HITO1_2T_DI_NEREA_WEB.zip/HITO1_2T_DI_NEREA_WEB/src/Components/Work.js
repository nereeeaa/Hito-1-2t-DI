import React from "react";
import PickMeals from "../Assets/pick-meals-image.png";
import ChooseMeals from "../Assets/choose-image.png";
import DeliveryMeals from "../Assets/delivery-image.png";

const Work = () => {
  const workInfoData = [
    {
      image: PickMeals,
      title: "Elige tu comida",
      text: "Elige lo que más te apetezca comer de nuestra gran lista de comidas.",
    },
    {
      image: ChooseMeals,
      title: "Elige cuando",
      text: "Elige a que hora quieres que te lo entregemos.",
    },
    {
      image: DeliveryMeals,
      title: "Entragas rápidas",
      text: "Y el pedido llegará rápido para que disfrutes de la maravillosa comida que ofrecemos.",
    },
  ];
  return (
    <div id="trabajo" className="work-section-wrapper">
      <div className="work-section-top">
        <p className="primary-subheading">Funcionamiento</p>
        <h1 className="primary-heading">Como funciona</h1>
        <p className="primary-text">
          En Foodie queremos ser tu opción de confianza por lo que pedir será super sencillo, 
          solo tienes que seguir esos pasos y cuando menos te lo esperes podrás estar disfrutando de nuestra rica comida.
        </p>
      </div>
      <div className="work-section-bottom">
        {workInfoData.map((data) => (
          <div className="work-section-info" key={data.title}>
            <div className="info-boxes-img-container">
              <img src={data.image} alt="" />
            </div>
            <h2>{data.title}</h2>
            <p>{data.text}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Work;
